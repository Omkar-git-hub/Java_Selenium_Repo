package Extentions;
import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class UI_Element_Extentions 
{
	// Perform Enter Text Operation
	public static void performEnterText(WebDriver Driver, By locator, String value)
	{
		Driver.findElement(locator).click();
		Driver.findElement(locator).clear();
		Driver.findElement(locator).sendKeys(value);
	}
	
	// Perform Click operation
	public static void performClick(WebDriver Driver, By locator)
	{
		Driver.findElement(locator).click();
	}
	
	// Perform DropDown selection By Text
	public static void performDropDownSelectionByText(WebDriver Driver, By locator, String dropDownValue)
	{
		var select = new Select(Driver.findElement(locator));
		select.selectByValue(dropDownValue);
	}

	// Perform DropDown selection By index
	public static void performDropDownSelectionByIndex(WebDriver Driver, By locator, int index)
	{
		var select = new Select(Driver.findElement(locator));
		select.selectByIndex(index);
	}
	
	

}
