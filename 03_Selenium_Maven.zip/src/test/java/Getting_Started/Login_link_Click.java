package Getting_Started;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class Login_link_Click 
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 1.Create a WebDriver 
		WebDriver Driver = new EdgeDriver();
		
		// 2.Navigate to WebApp
		Driver.navigate().to("http://eaapp.somee.com/");
		
		
		// 3.1 Identify the login using ID 
		By lnkLogin = By.id("loginLink"); 
		// OR 
		// 3.2 Identify the login using linkText()
		// By locator = By.linkText("Login"); 
		
		
		// Pass the locator to WebDriver which can help to operation on UI
		WebElement element = Driver.findElement(lnkLogin);
		
		// Perform Operation on the UI - Clicking in our case
		element.click();
		
		
		
		By txtUsername = By.name("UserName");
		
		var txtUsernameElement = Driver.findElement(txtUsername);
		
		txtUsernameElement.sendKeys("admin");
		
		

	}

}
