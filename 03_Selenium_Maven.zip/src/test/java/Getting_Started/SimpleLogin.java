package Getting_Started;

import org.openqa.selenium.*;
import org.openqa.selenium.edge.EdgeDriver;

public class SimpleLogin {
    public static void main(String[] args) {
        WebDriver driver = new EdgeDriver();
        driver.get("http://eaapp.somee.com/");
        
        // Set Full Screen mode
        driver.manage().window().maximize();

        // Click Login Link
        driver.findElement(By.id("loginLink")).click();

        // Enter Username & Password
        driver.findElement(By.name("UserName")).sendKeys("admin");
        driver.findElement(By.name("Password")).sendKeys("password");

        // Click Login Button
        driver.findElement(By.cssSelector(".btn")).submit();
    }
}
