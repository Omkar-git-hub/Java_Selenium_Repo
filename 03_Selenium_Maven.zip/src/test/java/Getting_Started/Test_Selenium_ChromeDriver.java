package Getting_Started;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test_Selenium_ChromeDriver {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		// 1.Create a WebDriver 
		// 2.Launch the Browser
		WebDriver Driver = new ChromeDriver();
		
		// Navigate to Specific URL
		Driver.navigate().to("https://www.google.com");
		

	}

}
