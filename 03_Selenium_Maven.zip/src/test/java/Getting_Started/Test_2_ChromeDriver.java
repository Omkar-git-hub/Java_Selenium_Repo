package Getting_Started;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test_2_ChromeDriver {
    public static void main(String[] args) throws InterruptedException {
        // Create WebDriver Chrome
        WebDriver Driver = new ChromeDriver();

        // Launch Chrome Browser
        Driver.get("https://www.w3schools.com/java/java_intro.asp");
        //Driver.navigate().to("https://www.w3schools.com/java/java_intro.asp")

        // Set the Screen as Full Screen
        Driver.manage().window().fullscreen();

        // Print the URL 
        String URL = Driver.getCurrentUrl();
        System.out.println("The Current URL : " + URL );

        // Minimizing the Full Screen
        Driver.manage().window().minimize();

        // Add delay before closing
        Thread.sleep(2000);

        // Closing the window
        Driver.close();
    }
}
