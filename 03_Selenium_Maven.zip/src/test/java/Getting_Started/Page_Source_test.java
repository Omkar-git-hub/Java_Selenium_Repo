package Getting_Started;

import org.openqa.selenium.*;
import org.openqa.selenium.edge.EdgeDriver;

public class Page_Source_test 
{
	public static void main(String[] args)
	{
		// Create WebDriver
		WebDriver Driver = new EdgeDriver();
		
		// Navigate  to Browser
		Driver.get("https://www.google.com/");
		
		// Set Full Screen Mode
		Driver.manage().window().fullscreen();
		
		// Printing URL 
		System.out.println("URL Link : " + Driver.getCurrentUrl());
		
		// Printing Handle
		System.out.println("The Browser Handle : " + Driver.getWindowHandle() );
		
		String PageSource = Driver.getPageSource();
		
		if (PageSource.contains("Copyright Google LLC"))
		{
			System.out.println("True");
		}
		else
		{
			System.out.println("False");
		}
		
		// 
		
		
	}

}
