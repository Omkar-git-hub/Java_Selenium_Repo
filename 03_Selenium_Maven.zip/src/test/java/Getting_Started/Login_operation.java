package Getting_Started;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class Login_operation 
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 1.Create a WebDriver 
		WebDriver Driver = new EdgeDriver();
		
		// 2.Navigate to WebApp
		Driver.navigate().to("http://eaapp.somee.com/");
		
		
		// 3.1 Identify the login using ID 
		By lnkLogin = By.id("loginLink"); 
		// OR 
		// 3.2 Identify the login using linkText()
		// By lnkLogin = By.linkText("Login"); 
		
		
		// Pass the locator to WebDriver which can help to operation on UI
		WebElement lgnelement = Driver.findElement(lnkLogin);
		
		// Perform Operation on the UI - Clicking in our case
		lgnelement.click();
		
		
		
		// Giving Input for Username as an admin
		By txtUsername = By.name("UserName");
		var txtUsernameElement = Driver.findElement(txtUsername);
		txtUsernameElement.sendKeys("admin");
		
		// Giving Input for Password
		By txtPassword = By.name("Password");
		var txtPasswordElement = Driver.findElement(txtPassword);
		txtPasswordElement.sendKeys("password");
		
		// Finding login button for click
		WebElement lngclk = Driver.findElement(By.id("loginIn"));
		
		//Clicking Login Button to Login Operation
		lngclk.click();

	}

}
