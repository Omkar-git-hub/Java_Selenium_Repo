package Getting_Started;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class HW_2_create_employee 
{
	public static void main(String[] args) 
	{
		// Open Edge browser
		WebDriver driver = new EdgeDriver();
		
		// Open the website
        driver.get("http://eaapp.somee.com/");
        
        // Maximize the browser window
        driver.manage().window().maximize();

        // Click on the Login link
        driver.findElement(By.id("loginLink")).click();

        // Enter Username and Password
        driver.findElement(By.name("UserName")).sendKeys("admin");
        driver.findElement(By.name("Password")).sendKeys("password");

        // Click the Login button
        driver.findElement(By.cssSelector(".btn")).submit();
        
        // Click on "Employee List" link
        driver.findElement(By.linkText("Employee List")).click();
        
        // Click on "Create New" link
        driver.findElement(By.linkText("Create New")).click();
        
        // Fill employee details
        driver.findElement(By.name("Name")).sendKeys("Omkar");  // Enter Name
        driver.findElement(By.name("Salary")).sendKeys("12000");  // Enter Salary
        driver.findElement(By.name("DurationWorked")).sendKeys("6");  // Enter Work Duration
        driver.findElement(By.className("form-control")).click();  // Click Dropdown (if needed)
        driver.findElement(By.name("Email")).sendKeys("omkarnikam.hello@gmail.kom");  // Enter Email
        
        // Click on "Create" button
        driver.findElement(By.cssSelector(".btn")).click();
        
        // Search for the created employee
        driver.findElement(By.name("searchTerm")).sendKeys("Omkar");  // Enter name in search box
        driver.findElement(By.className("btn-default")).click();  // Click search button
	}
}
