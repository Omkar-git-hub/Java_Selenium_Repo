package Getting_Started;

import javax.xml.xpath.XPath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

public class End_to_End_Automation_17 
{
	public static void main(String[] args) {
        // Open Edge browser
        WebDriver driver = new EdgeDriver();
        
        // Open the Website
        driver.get("http://eaapp.somee.com/");
        
        // Maximize the browser window
        driver.manage().window().maximize();
        
        // 1. Perform login
        login(driver);
        
        // 2. Create a new employee
        createEmployee(driver);
        
        // 3. Log off operation
		/* logOff(driver); */
        
        // 3. Search Employee
        searchEmployee(driver);
    }

    // Method for Login Operation
    public static void login(WebDriver driver) {
        driver.findElement(By.id("loginLink")).click(); // Click on the Login link
        driver.findElement(By.name("UserName")).sendKeys("admin"); // Enter Username
        driver.findElement(By.name("Password")).sendKeys("password"); // Enter Password
        driver.findElement(By.cssSelector(".btn")).submit(); // Click Login button
    }

    // Method for Creating New Employee
    public static void createEmployee(WebDriver driver) {
        driver.findElement(By.linkText("Employee List")).click(); // Click on Employee List
        driver.findElement(By.linkText("Create New")).click(); // Click on Create New
        
        // Fill employee details
        driver.findElement(By.name("Name")).sendKeys("Omkar"); // Enter Name
        
        // Selecting from DropDown Options
        Select selectGrade = new Select(driver.findElement(By.id("Grade")));
        selectGrade.selectByContainsVisibleText("Middle");
        
        driver.findElement(By.name("DurationWorked")).sendKeys("6"); // Enter Work Duration
        driver.findElement(By.className("form-control")).click(); // Click Dropdown (if needed)
        driver.findElement(By.name("Email")).sendKeys("omkarnikam.hello@gmail.kom"); // Enter Email
        driver.findElement(By.cssSelector(".btn")).click(); // Click Create button
        
        
        if(driver.findElement(By.xpath("//span[text()='The Salary field is required.']")).isDisplayed())
        {
        	driver.findElement(By.name("Salary")).sendKeys("10000");
        	
        	// Selecting from DropDown Options
            Select selectGrade1 = new Select(driver.findElement(By.id("Grade")));
            selectGrade1.selectByValue("4"); // Or selectByVisibleText("")
            
            driver.findElement(By.className("btn")).click();
        }
        else
        {
        	// do nothing
        }
    }
    
    public static void searchEmployee(WebDriver driver)
    {
    	driver.findElement(By.name("searchTerm")).sendKeys("Omkar");
    	driver.findElement(By.cssSelector(".btn.btn-default")).click();

    }


	// Method for Log Off Operation
//    public static void logOff(WebDriver driver) {
//        driver.findElement(By.linkText("Log off")).click(); // Click Log Off link
//    }
}





    