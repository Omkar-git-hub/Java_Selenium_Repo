
package POM_Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class CreateEmpPage {
    private WebDriver driver;

    public CreateEmpPage(WebDriver driver) {
        this.driver = driver;
    }

    private By txtName = By.name("Name");
    private By txtDuration = By.name("DurationWorked");
    private By txtEmail = By.name("Email");
    private By txtSalary = By.name("Salary");
    private By ddlGrade = By.id("Grade");
    private By btnSubmit = By.cssSelector(".btn");

    public EmpListPage createNewEmp(String name, String duration, String email, String salary, String grade) {
        driver.findElement(txtName).sendKeys(name);
        driver.findElement(txtDuration).sendKeys(duration);
        driver.findElement(txtEmail).sendKeys(email);
        driver.findElement(txtSalary).sendKeys(salary);
        new Select(driver.findElement(ddlGrade)).selectByVisibleText(grade);
        driver.findElement(btnSubmit).click();
        return new EmpListPage(driver);
    }
}