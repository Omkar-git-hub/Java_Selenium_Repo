package POM_Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class POM_code_end_to_end {
    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();

        try {
            driver.navigate().to("http://eaapp.somee.com/");
            driver.manage().window().maximize();

            HomePage homePage = new HomePage(driver);
            LoginPage loginPage = homePage.clickLogin();
            homePage = loginPage.performLogin("admin", "password");

            EmpListPage empListPage = homePage.clickEmpList();
            CreateEmpPage createEmpPage = empListPage.clickCreateNew();

            createEmpPage.createNewEmp("Pratik", "19", "Pratik.chavan@example.com", "15000", "Middle");

            Thread.sleep(3000);
        } finally {
            driver.quit();
        }
    }
}