package POM_Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class EmpListPage {
    private WebDriver driver;

    public EmpListPage(WebDriver driver) {
        this.driver = driver;
    }

    private By btnCreateNew = By.linkText("Create New");

    public CreateEmpPage clickCreateNew() {
        driver.findElement(btnCreateNew).click();
        return new CreateEmpPage(driver);
    }
}