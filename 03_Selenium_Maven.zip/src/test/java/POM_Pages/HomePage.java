package POM_Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
    private WebDriver driver;

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    private By lnkLogin = By.linkText("Login");
    private By lnkEmplist = By.linkText("Employee List");

    public LoginPage clickLogin() {
        driver.findElement(lnkLogin).click();
        return new LoginPage(driver);
    }

    public EmpListPage clickEmpList() {
        driver.findElement(lnkEmplist).click();
        return new EmpListPage(driver);
    }
}