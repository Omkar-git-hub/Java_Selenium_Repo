package Custom_UI_control_methods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import Extentions.UI_Element_Extentions;

public class automationUsingMethods {
    public static void main(String[] args) {
        // Open Edge browser
        WebDriver driver = new EdgeDriver();
        
        // Open the Website
        driver.get("http://eaapp.somee.com/");
        
        // Maximize the browser window
        driver.manage().window().maximize();
        
        // 1. Perform login
        login(driver);
        
    }

    // Method for Login Operation
    public static void login(WebDriver driver) {
        UI_Element_Extentions.performClick(driver, By.linkText("Login"));
        
        UI_Element_Extentions.performEnterText(driver, By.name("UserName"), "admin");
        
        UI_Element_Extentions.performEnterText(driver, By.name("Password"), "password");
        
        UI_Element_Extentions.performClick(driver, By.id("loginIn"));
    }


}
