package Custom_UI_control_methods;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import POM_Pages.HomePage;


public class POM_code_end_to_end {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver driver = new ChromeDriver();
		
		driver.navigate().to("http://eaapp.somee.com/");
		driver.manage().window().maximize();
		
		HomePage homePage = new HomePage(driver);
		var loginPage = homePage.clickLogin();
		homePage =  loginPage.performLogin("admin", "password");
		var empListPage = homePage.clickEmpList();
		var createEmpPage = empListPage.clickCreateNew();
		
		
		createEmpPage.createNewEmp("Rahul", "9", "rahul.chavan@example.com", "15000", "Middle");
		
		
		// Wait for 3 seconds (3000 milliseconds)
		Thread.sleep(3000);  

		// Quit the browser
		driver.quit();  


	}

}