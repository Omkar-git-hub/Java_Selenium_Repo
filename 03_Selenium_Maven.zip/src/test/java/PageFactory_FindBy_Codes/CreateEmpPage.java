// ----------- CreateEmpPage.java -----------
package PageFactory_FindBy_Codes;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CreateEmpPage {
    private WebDriver driver;

    public CreateEmpPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(name = "Name")
    private WebElement txtName;

    @FindBy(id = "DurationWorked")
    private WebElement txtDuration;

    @FindBy(name = "Email")
    private WebElement txtEmail;

    @FindBy(name = "Salary")
    private WebElement txtSalary;

    @FindBy(id = "Grade")
    private WebElement ddlGrade;

    @FindBy(css = ".btn")
    private WebElement btnClick;

    public EmpListPage createNewEmp(String name, String duration, String email, String salary, String grade) {
        txtName.clear();
        txtName.sendKeys(name);
        txtDuration.clear();
        txtDuration.sendKeys(duration);
        txtEmail.clear();
        txtEmail.sendKeys(email);
        txtSalary.clear();
        txtSalary.sendKeys(salary);
        new Select(ddlGrade).selectByVisibleText(grade);
        btnClick.click();
        return new EmpListPage(driver);
    }
}