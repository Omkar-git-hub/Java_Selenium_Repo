// ----------- POM_PageFactory_FindBy.java -----------
package PageFactory_FindBy_Codes;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class POM_PageFactory_FindBy {
    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        

        driver.navigate().to("http://eaapp.somee.com/");
        driver.manage().window().maximize();

        HomePage homePage = new HomePage(driver);
        LoginPage loginPage = homePage.clickLogin();
        homePage = loginPage.performLogin("admin", "password");

        // Reinitialize homepage after login to avoid stale element reference
        homePage = new HomePage(driver);
        EmpListPage empListPage = homePage.clickEmpList();

        // Reinitialize empListPage to ensure valid DOM elements
        empListPage = new EmpListPage(driver);
        CreateEmpPage createEmpPage = empListPage.clickCreateNew();

        // Create a new employee
        createEmpPage.createNewEmp("ritesh", "1122", "muktar@example.com", "19000", "Middle");

        //Thread.sleep(3000);
        //driver.quit();
    }
}