// ----------- Test_CreateEmployee.java -----------
package TestNG_Codes;

import PageFactory_FindBy_Codes.*;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

public class TestNG_Code2 {

	private WebDriver driver;
	private HomePage homePage;

	@BeforeClass
	public void setUp() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("http://eaapp.somee.com/");
		homePage = new HomePage(driver);
	}

	@Test(priority = 1)
	public void loginTest() {
		LoginPage loginPage = homePage.clickLogin();
		homePage = loginPage.performLogin("admin", "password");
	}

	@Test(priority = 2, dependsOnMethods = "loginTest")
	public void createEmployeeTest() {
		EmpListPage empListPage = homePage.clickEmpList();
		CreateEmpPage createEmpPage = empListPage.clickCreateNew();

		// Create a new employee
		createEmpPage.createNewEmp("Rutu", "1122", "muktar@example.com", "19000", "Middle");
	}

	/*
	 * @AfterClass public void tearDown() { if (driver != null) { driver.quit(); } }
	 */
}
