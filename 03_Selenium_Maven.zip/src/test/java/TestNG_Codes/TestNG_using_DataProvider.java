package TestNG_Codes;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import PageFactory_FindBy_Codes.HomePage;
import PageFactory_FindBy_Codes.LoginPage;
import PageFactory_FindBy_Codes.CreateEmpPage;
import PageFactory_FindBy_Codes.EmpListPage;

public class TestNG_using_DataProvider {
    private WebDriver driver;
    private HomePage homePage;

    @BeforeClass
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.navigate().to("http://eaapp.somee.com/");
        homePage = new HomePage(driver);
    }

    @Test(dataProvider = "CreateEmp")
    public void testwithDataProvider(String name, String duration, String email, String salary, String role) {
        HomePage homePage = new HomePage(driver);
        LoginPage loginPage = homePage.clickLogin();
        homePage = loginPage.performLogin("admin", "password");
        EmpListPage employeeListPage = homePage.clickEmpList();
        CreateEmpPage createEmployeePage = employeeListPage.clickCreateNew();
        createEmployeePage.createNewEmp(name, duration, email, salary, role);
        homePage.clickLogin();
    }

    @DataProvider(name = "CreateEmp")
    public static Object[][] createEmpData() {
        return new Object[][] {
            { "Fakir", "10", "Fakir@gmail.com", "12000", "Middle" }
        };
    }
}
