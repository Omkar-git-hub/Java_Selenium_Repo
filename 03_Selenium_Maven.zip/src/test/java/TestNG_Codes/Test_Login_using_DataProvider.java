package TestNG_Codes;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Test_Login_using_DataProvider {

    WebDriver driver;

    @BeforeClass
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @DataProvider(name = "loginData")
    public Object[][] loginCredentials() {
        return new Object[][] {
            {"admin", "admin123"},
            {"admin", "password"},
        };
    }

    @Test(dataProvider = "loginData")
    public void loginTest(String username, String password) throws InterruptedException {
        driver.get("http://eaapp.somee.com/");

        // Click Login link
        driver.findElement(By.linkText("Login")).click();

        // Fill login details
        driver.findElement(By.id("UserName")).sendKeys(username);
        driver.findElement(By.id("Password")).sendKeys(password);

        // Click Login button
        driver.findElement(By.cssSelector("input[type='submit']")).click();

        // Wait for a bit
        Thread.sleep(2000);
}

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}
